#include "MutualFunctions.h"

int main() 
{
    startMenu();
	return 0;
}